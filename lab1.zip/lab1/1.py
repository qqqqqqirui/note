# import numpy
# list1=list(map(int, input().split()))
# def prod3(l):
#     result=numpy.prod(l)
#     print(result)
# prod3(list1)
def prod3(a, b, c):
    return a*b*c
