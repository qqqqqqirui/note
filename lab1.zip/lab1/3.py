def bmi(weight, height):
    return weight/pow(height, 2)
print(bmi(49, 1.59))