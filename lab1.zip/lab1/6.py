def compareLength(m, n):
    if len(m)==len(n):
        print(len(m))
        return True
    else:
        return False