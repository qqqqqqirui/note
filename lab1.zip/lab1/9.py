def sort(a, b, c):
    newlist=sorted([a, b, c])
    for i in newlist:
        print(i)
