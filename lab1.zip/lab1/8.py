def sumDigit(number):
    l=list(map(int, list(str(number))))
    return sum(l)