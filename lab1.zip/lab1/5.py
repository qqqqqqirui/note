def dividend(rest, quotient, divisor):
    return quotient*divisor + rest
